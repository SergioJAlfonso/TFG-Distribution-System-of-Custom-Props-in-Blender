import bpy 
from mathutils import Euler
from ...utilsSS.blender_utils import *
from ...utilsSS.geometry_utils import *

class Redistribute_OT_Operator(bpy.types.Operator):
    bl_idname = "addon.redistribute"
    bl_label = "Redistribute Operator"
    bl_description = "Redistribute objects over a surface"

    def execute(self, context):
        if(context.scene.solution_nodes == []):
            self.report({'WARNING'}, 'Nothing to redistribute!')
            return {'FINISHED'}
        
        if(context.scene.current_search-1 >= len(context.scene.solution_nodes)):
            self.report({'WARNING'}, 'Nothing to redistribute!')
            return {'FINISHED'}
        
        
        if (context.scene.subdivide): 
            target = duplicateObject(context.scene.target)
        else:
             target = context.scene.target
        asset = context.scene.asset

        #Note : bpy.types.Scene.num_assets != context.scene.num_assets
        #Get user property data
        numCutsSubdivision = context.scene.num_cuts
        nameCollection = context.scene.collectName
        threshold_weight = context.scene.threshold #valor de 0, 1
        
        collection = bpy.data.collections.get(nameCollection)
        collection = initCollection(collection, nameCollection, True)

        bpy.ops.object.select_all(action='DESELECT')

        # #Get bounding box
        asset_bounding_box_local = getBoundingBox(context, asset)
        target_bounding_box_local = getBoundingBox(context, target)

        # #Subdivide target to fit assets in every vertex
        if (context.scene.subdivide):
            makeSubdivision(target, asset_bounding_box_local, target_bounding_box_local, numCutsSubdivision)

        data_tridimensional = getVerticesData(target)
        print('Algorithm:', context.scene.algorithm_enum)

        vertices = filterVerticesByWeightThreshold(data_tridimensional, threshold_weight)
        #Initial state as all possible vertices to place an asset

        return change_search(self, context, context.scene.solution_nodes[context.scene.current_search-1], vertices, asset, asset_bounding_box_local, collection, target)