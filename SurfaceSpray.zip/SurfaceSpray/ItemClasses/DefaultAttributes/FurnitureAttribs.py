from ..ItemRules import *
class FurnitureAttribs(ItemRules):
    def __init__(self):
        self.rotations = [0,0,1]
        self.distance_offset = 0
        self.max_repetitions = -1